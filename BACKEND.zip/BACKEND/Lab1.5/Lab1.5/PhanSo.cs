﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1._5
{
    internal class PhanSo
    {
        public int tuSo { get; set; }
        public int mauSo { get; set; }

        public PhanSo()
        {
            tuSo = 0;
            mauSo = 1;
        }

        public PhanSo(int tuSo, int mauSo)
        {
            this.tuSo = tuSo;
            this.mauSo = mauSo == 0 ? 1 : mauSo;
        }

        public void Nhap()
        {
            Console.Write("- Nhập tử số: ");
            tuSo = int.Parse(Console.ReadLine());
            Console.Write("- Nhập mẫu số: ");
            mauSo = int.Parse(Console.ReadLine());
            if (mauSo == 0)
            {
                Console.WriteLine("Mẫu số không được bằng 0. Đặt lại mẫu số = 1.");
                mauSo = 1;
            }
        }

        public override string ToString()
        {
            return $"{tuSo}/{mauSo}";
        }

        public static PhanSo Cong(PhanSo a, PhanSo b)
        {
            int tu = a.tuSo * b.mauSo + b.tuSo * a.mauSo;
            int mau = a.mauSo * b.mauSo;
            return RutGon(new PhanSo(tu, mau));
        }

        public static PhanSo RutGon(PhanSo ps)
        {
            int ucln = UCLN(ps.tuSo, ps.mauSo);
            return new PhanSo(ps.tuSo / ucln, ps.mauSo / ucln);
        }

        private static int UCLN(int a, int b)
        {
            a = Math.Abs(a);
            b = Math.Abs(b);
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }

    }
}
