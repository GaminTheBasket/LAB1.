﻿using System;
using System.Collections.Generic;
using System.Text;
using Lab1._5;
using LAB2;

namespace LAB2
{
    class Program
    {
        public static List<PhanSo> danhSachPhanSo = new List<PhanSo>();

        public static void getMenu()
        {
            int n;
            do
            {
                Console.Clear();
                Console.OutputEncoding = Encoding.UTF8;
                Console.WriteLine("---------- CHƯƠNG TRÌNH TÍNH TỔNG PHÂN SỐ ----------");
                Console.WriteLine("1. Nhập phân số");
                Console.WriteLine("2. Hiển thị danh sách phân số");
                Console.WriteLine("3. Tính tổng phân số");
                Console.WriteLine("4. Thoát");
                Console.Write("- Chọn chức năng: ");
                n = int.Parse(Console.ReadLine());

                switch (n)
                {
                    case 1:
                        {
                            PhanSo ps = new PhanSo();
                            ps.Nhap();
                            danhSachPhanSo.Add(ps);
                            Console.WriteLine("Thêm thành công!");
                            Console.ReadLine();
                        }
                        break;
                    case 2:
                        {
                            Console.WriteLine("Danh sách phân số:");
                            foreach (var ps in danhSachPhanSo)
                            {
                                Console.WriteLine(ps.ToString());
                            }
                            Console.ReadLine();
                        }
                        break;
                    case 3:
                        {
                            if (danhSachPhanSo.Count == 0)
                            {
                                Console.WriteLine("Danh sách trống!");
                            }
                            else
                            {
                                PhanSo tong = danhSachPhanSo[0];
                                for (int i = 1; i < danhSachPhanSo.Count; i++)
                                {
                                    tong = PhanSo.Cong(tong, danhSachPhanSo[i]);
                                }
                                Console.WriteLine($"Tổng các phân số: {tong}");
                            }
                            Console.ReadLine();
                        }
                        break;
                    case 4:
                        Console.WriteLine("Kết thúc chương trình.");
                        break;
                    default:
                        Console.WriteLine("Chọn sai chức năng!");
                        break;
                }
            } while (n != 4);
        }

        static void Main(string[] args)
        {
            getMenu();
        }
    }
}
