﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai2Lad1._5
{
    public class HinhTamGiac : Hinh
    {
        public double a, b, c;

        public override void Nhap()
        {
            Console.Write("- Nhập cạnh a: ");
            a = double.Parse(Console.ReadLine());
            Console.Write("- Nhập cạnh b: ");
            b = double.Parse(Console.ReadLine());
            Console.Write("- Nhập cạnh c: ");
            c = double.Parse(Console.ReadLine());
            if (a + b <= c || a + c <= b || b + c <= a)
            {
                Console.WriteLine("Ba cạnh không tạo thành tam giác. Mặc định về tam giác đều cạnh 1.");
                a = b = c = 1;
            }
        }

        public override double TinhChuVi()
        {
            return a + b + c;
        }

        public override double TinhDienTich()
        {
            double p = (a + b + c) / 2;
            return Math.Sqrt(p * (p - a) * (p - b) * (p - c)); // Công thức Heron
        }

        public override string TenHinh()
        {
            return "Hình Tam Giác";
        }
    }
}
