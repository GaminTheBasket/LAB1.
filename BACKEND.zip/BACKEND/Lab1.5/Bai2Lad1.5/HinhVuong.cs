﻿using System;


namespace Bai2Lad1._5
{
    public class HinhVuong : Hinh
    {
        public double Canh { get; set; }

        public override void Nhap()
        {
            Console.Write("- Nhập cạnh: ");
            Canh = double.Parse(Console.ReadLine());
        }

        public override double TinhChuVi()
        {
            return 4 * Canh;
        }

        public override double TinhDienTich()
        {
            return Canh * Canh;
        }

        public override string TenHinh()
        {
            return "Hình Vuông";
        }
    }
}
