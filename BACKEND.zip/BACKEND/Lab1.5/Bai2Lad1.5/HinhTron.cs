﻿using System;

namespace Bai2Lad1._5
{
    public class HinhTron : Hinh
    {
        public double BanKinh { get; set; }

        public override void Nhap()
        {
            Console.Write("- Nhập bán kính: ");
            BanKinh = double.Parse(Console.ReadLine());
        }

        public override double TinhChuVi()
        {
            return 2 * Math.PI * BanKinh;
        }

        public override double TinhDienTich()
        {
            return Math.PI * BanKinh * BanKinh;
        }

        public override string TenHinh()
        {
            return "Hình Tròn";
        }
    }
}
