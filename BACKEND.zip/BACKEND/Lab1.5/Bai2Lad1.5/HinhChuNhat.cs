﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai2Lad1._5
{
    public class HinhChuNhat : Hinh
    {
        public double Dai { get; set; }
        public double Rong { get; set; }

        public override void Nhap()
        {
            Console.Write("- Nhập chiều dài: ");
            Dai = double.Parse(Console.ReadLine());
            Console.Write("- Nhập chiều rộng: ");
            Rong = double.Parse(Console.ReadLine());
        }

        public override double TinhChuVi()
        {
            return 2 * (Dai + Rong);
        }

        public override double TinhDienTich()
        {
            return Dai * Rong;
        }

        public override string TenHinh()
        {
            return "Hình Chữ Nhật";
        }
    }
}
