﻿using System;
using System.Collections.Generic;
using System.Text;
using Bai2Lad1._5;

namespace Bai2Lad1._5
{
    class Program
    {
        public static List<Hinh> danhSachHinh = new List<Hinh>();

        static void getMenu()
        {
            int chon;
            do
            {
                Console.Clear();
                Console.OutputEncoding = Encoding.UTF8;
                Console.WriteLine("----- CHƯƠNG TRÌNH TÍNH TOÁN HÌNH HỌC -----");
                Console.WriteLine("1. Thêm Hình Tròn");
                Console.WriteLine("2. Thêm Hình Vuông");
                Console.WriteLine("3. Thêm Hình Chữ Nhật");
                Console.WriteLine("4. Thêm Hình Tam Giác");
                Console.WriteLine("5. Hiển thị danh sách và tổng chu vi, diện tích");
                Console.WriteLine("6. Thoát");
                Console.Write("- Mời chọn chức năng: ");
                chon = int.Parse(Console.ReadLine());

                Hinh hinh = null;
                switch (chon)
                {
                    case 1:
                        hinh = new HinhTron(); break;
                    case 2:
                        hinh = new HinhVuong(); break;
                    case 3:
                        hinh = new HinhChuNhat(); break;
                    case 4:
                        hinh = new HinhTamGiac(); break;
                    case 5:
                        HienThiDanhSach();
                        Console.ReadLine();
                        continue;
                    case 6:
                        Console.WriteLine("Kết thúc chương trình.");
                        return;
                    default:
                        Console.WriteLine("Chức năng không hợp lệ!");
                        Console.ReadLine();
                        continue;
                }

                if (hinh != null)
                {
                    hinh.Nhap();
                    danhSachHinh.Add(hinh);
                    Console.WriteLine("Đã thêm " + hinh.TenHinh());
                    Console.ReadLine();
                }

            } while (chon != 6);
        }

        static void HienThiDanhSach()
        {
            double tongChuVi = 0, tongDienTich = 0;
            Console.WriteLine("----- DANH SÁCH CÁC HÌNH -----");
            foreach (var h in danhSachHinh)
            {
                Console.WriteLine($"{h.TenHinh()} | Chu vi: {h.TinhChuVi():0.00} | Diện tích: {h.TinhDienTich():0.00}");
                tongChuVi += h.TinhChuVi();
                tongDienTich += h.TinhDienTich();
            }
            Console.WriteLine("------------------------------------------");
            Console.WriteLine($"Tổng chu vi các hình: {tongChuVi:0.00}");
            Console.WriteLine($"Tổng diện tích các hình: {tongDienTich:0.00}");
        }

        static void Main(string[] args)
        {
            getMenu();
        }
    }
}

