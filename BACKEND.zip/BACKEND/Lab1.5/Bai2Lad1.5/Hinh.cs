﻿using System;

namespace Bai2Lad1._5
{
    public abstract class Hinh
    {
     public abstract double TinhChuVi();
     public abstract double TinhDienTich();
     public abstract void Nhap();
     public abstract string TenHinh();
    }
}
