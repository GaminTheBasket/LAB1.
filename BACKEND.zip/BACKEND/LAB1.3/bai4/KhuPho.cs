﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Bai4
{
    public class KhuPho
    {
        public List<HoDan> DanhSachHoDan { get; set; }

        public KhuPho()
        {
            DanhSachHoDan = new List<HoDan>();
        }

        public void NhapDanhSachHoDan()
        {
            Console.Write("Nhập số lượng hộ dân: ");
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"\nNhập thông tin hộ dân thứ {i + 1}:");
                HoDan hoDan = new HoDan();
                hoDan.Nhap();
                DanhSachHoDan.Add(hoDan);
            }
        }

        public void HienThiTatCa()
        {
            Console.WriteLine("\n--- Danh sách hộ dân trong khu phố ---");
            foreach (var ho in DanhSachHoDan)
            {
                ho.HienThi();
            }
        }

        public void TimTheoSoNha(int soNha)
        {
            var hoDan = DanhSachHoDan.FirstOrDefault(h => h.SoNha == soNha);
            if (hoDan != null)
            {
                hoDan.HienThi();
            }
            else
            {
                Console.WriteLine("Không tìm thấy hộ dân có số nhà này.");
            }
        }

        public void TimTheoTen(string ten)
        {
            bool found = false;
            foreach (var ho in DanhSachHoDan)
            {
                if (ho.TimTheoTen(ten))
                {
                    ho.HienThi();
                    found = true;
                }
            }
            if (!found)
            {
                Console.WriteLine("Không tìm thấy hộ dân có người tên này.");
            }
        }
    }
}
