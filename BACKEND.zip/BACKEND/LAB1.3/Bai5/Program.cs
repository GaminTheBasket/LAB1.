﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        KhachSan ks = new KhachSan();
        int chon;
        do
        {
            Console.WriteLine("\n===== MENU QUẢN LÝ KHÁCH SẠN =====");
            Console.WriteLine("1. Nhập danh sách khách thuê");
            Console.WriteLine("2. Hiển thị danh sách khách");
            Console.WriteLine("3. Tìm khách theo tên");
            Console.WriteLine("4. Tính tiền khách trả phòng");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn chức năng: ");
            chon = int.Parse(Console.ReadLine());

            switch (chon)
            {
                case 1: ks.NhapDS(); break;
                case 2: ks.HienThiDS(); break;
                case 3: ks.TimTheoTen(); break;
                case 4: ks.TinhTienKhach(); break;
            }

        } while (chon != 0);
    }
}
