﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bai2;

public class Quanly
{
    private List<TaiLieu> danhSach = new List<TaiLieu>();

    public void ThemTaiLieu()
    {
        Console.WriteLine("1. Sách\n2. Tạp chí\n3. Báo");
        Console.Write("Chọn loại tài liệu: ");
        int loai = int.Parse(Console.ReadLine());
        TaiLieu tl = null;

        switch (loai)
        {
            case 1: tl = new Sach(); break;
            case 2: tl = new TapChi(); break;
            case 3: tl = new Bao(); break;
        }

        if (tl != null)
        {
            tl.Nhap();
            danhSach.Add(tl);
        }
    }

    public void HienThiTatCa()
    {
        foreach (var tl in danhSach)
        {
            tl.HienThi();
            Console.WriteLine("-------------------");
        }
    }

    public void TimKiemTheoMa()
    {
        Console.Write("Nhập mã cần tìm: ");
        string ma = Console.ReadLine();
        foreach (var tl in danhSach)
        {
            if (tl.MaTaiLieu == ma)
            {
                tl.HienThi();
                return;
            }
        }
        Console.WriteLine("Không tìm thấy.");
    }
}
