﻿
using System;
class Program
{

    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        QLCB qlcb = new QLCB();
        int chon;

        do
        {
            Console.WriteLine("\n=== QUẢN LÝ CÁN BỘ ===");
            Console.WriteLine("1. Thêm cán bộ mới");
            Console.WriteLine("2. Tìm kiếm theo họ tên");
            Console.WriteLine("3. Hiển thị danh sách cán bộ");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn chức năng: ");
            chon = int.Parse(Console.ReadLine());

            switch (chon)
            {
                case 1:
                    qlcb.ThemCanBo();
                    break;
                case 2:
                    qlcb.TimKiemTheoTen();
                    break;
                case 3:
                    qlcb.HienThiDanhSach();
                    break;
                case 0:
                    Console.WriteLine("Thoát chương trình.");
                    break;
                default:
                    Console.WriteLine("Lựa chọn không hợp lệ.");
                    break;
            }

        } while (chon != 0);
    }
}
