﻿using System;

class Program
{
    // Hàm kiểm tra số nguyên tố
    static bool IsPrime(int number)
    {
        if (number <= 1) // Số nguyên tố phải lớn hơn 1
            return false;
        for (int i = 2; i <= Math.Sqrt(number); i++)
        {
            if (number % i == 0)
                return false; // Nếu có ước số khác ngoài 1 và chính nó, không phải số nguyên tố
        }
        return true; // Nếu không có ước số nào, thì là số nguyên tố
    }

    // Hàm nhập mảng từ bàn phím
    static int[] NhapMang(int n)
    {
        int[] mang = new int[n];
        Console.WriteLine("Nhap vao cac phan tu cua mang:");
        for (int i = 0; i < n; i++)
        {
            Console.Write($"Phan tu {i + 1}: ");
            mang[i] = int.Parse(Console.ReadLine());
        }
        return mang;
    }

    // Hàm hiển thị các phần tử là số nguyên tố trong mảng
    static void HienThiSoNguyenTo(int[] mang)
    {
        Console.WriteLine("Cac phan tu la so nguyen to trong mang:");
        for (int i = 0; i < mang.Length; i++)
        {
            if (IsPrime(mang[i]))
            {
                Console.WriteLine($"Chi so {i}: Gia tri {mang[i]}");
            }
        }
    }

    static void Main()
    {
        // Nhập số lượng phần tử của mảng
        Console.Write("Nhap so luong phan tu cua mang: ");
        int n = int.Parse(Console.ReadLine());

        // Nhập mảng từ bàn phím
        int[] mang = NhapMang(n);

        // Hiển thị các phần tử là số nguyên tố trong mảng
        HienThiSoNguyenTo(mang);
    }
}
