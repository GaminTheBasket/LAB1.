﻿using System;

class Program
{
    // Hàm tính tổng các số chẵn trong mảng
    static int TinhTongSoChan(int[] mang)
    {
        int tong = 0;

        // Duyệt qua tất cả các phần tử trong mảng
        foreach (var so in mang)
        {
            // Kiểm tra nếu số là số chẵn thì cộng vào tổng
            if (so % 2 == 0)
            {
                tong += so;
            }
        }

        return tong;
    }

    static void Main()
    {
        // Khởi tạo mảng các số nguyên
        int[] mang = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

        // Tính tổng các số chẵn trong mảng
        int tongSoChan = TinhTongSoChan(mang);

        // In kết quả
        Console.WriteLine($"Tong cac so chan trong mang la: {tongSoChan}");
    }
}
