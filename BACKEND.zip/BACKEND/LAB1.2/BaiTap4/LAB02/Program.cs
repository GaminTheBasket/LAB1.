﻿using System;

class Program
{
    // Ham tim so lon thu hai trong mang
    static int TimSoLonThuHai(int[] mang)
    {
        // Neu mang co it hon 2 phan tu, khong the tim so lon thu hai
        if (mang.Length < 2)
        {
            throw new InvalidOperationException("Mang phai co it nhat 2 phan tu.");
        }

        // Khoi tao hai bien de luu so lon nhat va so lon thu hai
        int max1 = int.MinValue; // So lon nhat
        int max2 = int.MinValue; // So lon thu hai

        // Duyet qua tung phan tu cua mang
        foreach (int so in mang)
        {
            if (so > max1) // Neu so hien tai lon hon so lon nhat
            {
                max2 = max1; // Cap nhat so lon thu hai
                max1 = so;   // Cap nhat so lon nhat
            }
            else if (so > max2 && so != max1) // Neu so hien tai lon hon so lon thu hai nhung khong bang so lon nhat
            {
                max2 = so; // Cap nhat so lon thu hai
            }
        }

        // Tra ve so lon thu hai
        return max2;
    }

    // Ham nhap mang tu ban phim
    static int[] NhapMang(int n)
    {
        int[] mang = new int[n];
        Console.WriteLine("Nhap vao cac phan tu cua mang:");
        for (int i = 0; i < n; i++)
        {
            Console.Write($"Phan tu {i + 1}: ");
            mang[i] = int.Parse(Console.ReadLine());
        }
        return mang;
    }

    static void Main()
    {
        // Nhap so luong phan tu trong mang
        Console.Write("Nhap so luong phan tu trong mang: ");
        int n = int.Parse(Console.ReadLine());

        // Nhap mang
        int[] mang = NhapMang(n);

        try
        {
            // Tim va in ra so lon thu hai
            int soLonThuHai = TimSoLonThuHai(mang);
            Console.WriteLine($"So lon thu hai trong mang la: {soLonThuHai}");
        }
        catch (InvalidOperationException ex)
        {
            Console.WriteLine(ex.Message); // Hien thi loi neu khong co du phan tu
        }
    }
}
