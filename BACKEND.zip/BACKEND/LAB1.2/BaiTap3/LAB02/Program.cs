﻿using System;

class Program
{
    // Ham de dem so luong so duong va so am trong mang
    static void DemSoDuongAm(int[] mang)
    {
        int soDuong = 0, soAm = 0;

        // Duyet qua mang de dem so luong so duong va so am
        foreach (int so in mang)
        {
            if (so > 0) // Neu so duong
            {
                soDuong++;
            }
            else if (so < 0) // Neu so am
            {
                soAm++;
            }
        }

        // In ket qua
        Console.WriteLine($"So luong so duong: {soDuong}");
        Console.WriteLine($"So luong so am: {soAm}");
    }

    // Ham nhap mang tu ban phim
    static int[] NhapMang(int n)
    {
        int[] mang = new int[n];
        Console.WriteLine("Nhap vao cac phan tu cua mang:");
        for (int i = 0; i < n; i++)
        {
            Console.Write($"Phan tu {i + 1}: ");
            mang[i] = int.Parse(Console.ReadLine());
        }
        return mang;
    }

    static void Main()
    {
        // Nhap so luong phan tu trong mang
        Console.Write("Nhap so luong phan tu trong mang: ");
        int n = int.Parse(Console.ReadLine());

        // Nhap mang
        int[] mang = NhapMang(n);

        // Dem so luong so duong va so am trong mang
        DemSoDuongAm(mang);
    }
}
