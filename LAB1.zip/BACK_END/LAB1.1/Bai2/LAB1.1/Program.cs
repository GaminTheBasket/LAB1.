﻿using System;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.InputEncoding = System.Text.Encoding.UTF8;
        Console.Write("Nhập chiều dài: ");
        double dai = double.Parse(Console.ReadLine());

        Console.Write("Nhập chiều rộng: ");
        double rong = double.Parse(Console.ReadLine());

        double dientich = dai * rong;
        Console.WriteLine($"Diện tích hình chữ nhật là: {dientich}");
    }
}
