﻿using System;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.InputEncoding = System.Text.Encoding.UTF8;
        Console.Write("Nhập số nguyên dương n: ");
        int n = int.Parse(Console.ReadLine());

        long giaithua = 1;
        for (int i = 1; i <= n; i++)
            giaithua *= i;

        Console.WriteLine($"Giai thừa của {n} là {giaithua}");
    }
}
