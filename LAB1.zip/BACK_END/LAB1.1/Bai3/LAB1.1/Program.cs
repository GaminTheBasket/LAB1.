﻿using System;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.InputEncoding = System.Text.Encoding.UTF8;
        Console.Write("Nhập nhiệt độ (°C): ");
        double c = double.Parse(Console.ReadLine());

        double f = (c * 9 / 5) + 32;
        Console.WriteLine($"Nhiệt độ tương đương: {f} °F");
    }
}
